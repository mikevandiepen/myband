<?php
/* Smarty version 3.1.32, created on 2018-06-04 09:06:34
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b14e4fad58ad9_60005789',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e0e5a62ad52d0138c6f8c7a7f7092f9b0151cf5' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\header.tpl',
      1 => 1527839641,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b14e4fad58ad9_60005789 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">
<head>

    <!-- Meta Data -->
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Page Title -->
    <title>MVC Model</title>

    <!-- CSS Links -->
    <link type="text/css" rel="stylesheet" href="assets/CSS/style.css">
    <link type="text/css" rel="stylesheet" href="assets/CSS/responsive.css">

    <!-- JS Links -->
    <?php echo '<script'; ?>
 src="/mvc/assets/JS/script.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php }
}
