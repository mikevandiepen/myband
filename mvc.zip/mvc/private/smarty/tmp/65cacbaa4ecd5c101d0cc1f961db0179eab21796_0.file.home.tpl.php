<?php
/* Smarty version 3.1.32, created on 2018-05-30 16:15:06
  from '/var/www/vhosts/25700.hosts.ma-cloud.nl/httpdocs/mvc/views/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b0eb1ea9c74e6_41271996',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '65cacbaa4ecd5c101d0cc1f961db0179eab21796' => 
    array (
      0 => '/var/www/vhosts/25700.hosts.ma-cloud.nl/httpdocs/mvc/views/home.tpl',
      1 => 1527689242,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b0eb1ea9c74e6_41271996 (Smarty_Internal_Template $_smarty_tpl) {
?><h1>Hallo Smarty</h1>
<p>Mijn naam is <?php echo $_smarty_tpl->tpl_vars['voornaam']->value;?>
</p><?php }
}
