<?php
/* Smarty version 3.1.32, created on 2018-06-04 09:10:58
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b14e6029c57b5_73480760',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ab4075a1e45a4e204b996f2476e2531a0d66bb33' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\home.tpl',
      1 => 1528096256,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b14e6029c57b5_73480760 (Smarty_Internal_Template $_smarty_tpl) {
?><h3>De mailadressen zijn:</h3><br>
<p>
    <ul>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['mailaddresses']->value, 'mail');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['mail']->value) {
?>
        <li><?php echo $_smarty_tpl->tpl_vars['mail']->value;?>
</li>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    <ul>
</p>
<?php }
}
