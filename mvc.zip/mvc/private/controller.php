<?php

function homepage_action() {
    // Model
    global $smarty;
    // Views
    $smarty->display('header.tpl');
    $smarty->display('navbar.tpl');
    $smarty->display('home.tpl');
    $smarty->display('footer.tpl');
}

function contact_action() {
    global $smarty;
    $smarty->display('header.tpl');
    $smarty->display('navbar.tpl');
    $smarty->display('contact.tpl');
    $smarty->display('footer.tpl');
}

function page_not_found_action() {
    global $smarty;
    $smarty->display('header.tpl');
    $smarty->display('navbar.tpl');
    $smarty->display('notfound.tpl');
    $smarty->display('footer.tpl');
}


function news_action(){
    // Model
    global $smarty, $pageno, $page, $searchterm;
    $articles = get_some_articles();
    $number_of_pages = get_number_of_pages();

    $smarty->assign('current_page', $pageno);
    $smarty->assign('number_of_pages', $number_of_pages);
    $smarty->assign('articles', $articles);

    // Views
    $smarty->display('header.tpl');
    $smarty->display('navbar.tpl');
    $smarty->display('news.tpl');
    $smarty->display('footer.tpl');
}


function display_page($page){
    global $smarty;
    $smarty->assign('title', strtoupper($page));
    $smarty->display('header.tpl');
    $smarty->display('menu.tpl');
    $smarty->display( $page . ' tpl');
    $smarty->display('footer.tpl');
}
