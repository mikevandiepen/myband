<?php

if (isset($_POST['fill'])) {
    for ($i = 1; $i <= 100; $i++) {
        insert_line($i);
    }
    echo "Inserted 100 rows.";
}

if (isset($_POST['empty'])) {
    empty_table();
    echo "Cleared table content.";
}

function con_db() {
    $mysqli = new mysqli('localhost', 'root', '', '25700_db');
    if ($mysqli->connect_errno) {
        echo 'Connection error: ' . $mysqli->connect_errno;
    }
    return $mysqli;
}

function insert_line($i) {
    $mysqli = con_db();
    $title = 'Title '.  $i;
    $content = 'Content '. $i;
    $image = 'Image '. $i;
    $query = "INSERT INTO articles VALUES (0,?,?,?)";
    $stmt = $mysqli->prepare($query) or die ('Error preparing');
    $stmt->bind_param('sss', $title, $content, $image) or die ('Error binding Params');
    $stmt->execute() or die ('Error executing');
}

function empty_table() {
    $mysqli = con_db();
    $query = "TRUNCATE articles";
    $stmt = $mysqli->prepare($query) or die ("Error preparing 2.");
    $stmt->execute() or die ("Error executing.");
}

function get_articles() {
    $mysqli = con_db();
    $query = "SELECT title FROM articles";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_result($title);
    $stmt->execute();
    $results = array();

    while ($stmt->fetch()) {
        $results[] = $title;
    }

    return $results;
}

function get_some_articles() {
    global $pageno, $searchterm;

    $mysqli = con_db();
    $firstrow = ($pageno -1) * ARTICLES_PER_PAGE;
    $per_page = ARTICLES_PER_PAGE;
    $query = "SELECT title, content, imagelink 
              from articles 
              WHERE title LIKE ? 
              OR content LIKE ?
              ORDER BY article_id
              DESC LIMIT $firstrow, $per_page
              ";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param('ss', $searchterm, $searchterm);
    $stmt->bind_result($title, $content,$imagelink);
    $stmt->execute();
    $results = array();
    while ($stmt->fetch()) {
        $article = array();
        $article[] = $title;
        $article[] = $content;
        $article[] = $imagelink;
        $results[] = $article;
    }
    return $results;
}

function calculate_pages() {
    $mysqli = con_db();
    $query = "SELECT * FROM articles";
    $result = $mysqli->query($query);
    $rows = $result->num_rows;
    $number_of_pages = ceil($rows / ARTICLES_PER_PAGE);

    return $number_of_pages;
}


function get_number_of_pages() {
    $number_of_pages = calculate_pages();
    return $number_of_pages;
}