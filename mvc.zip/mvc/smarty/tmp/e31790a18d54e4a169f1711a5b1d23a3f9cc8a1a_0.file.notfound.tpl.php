<?php
/* Smarty version 3.1.32, created on 2018-06-25 10:20:42
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\notfound.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b30a5da4849c7_30155385',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e31790a18d54e4a169f1711a5b1d23a3f9cc8a1a' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\notfound.tpl',
      1 => 1528095386,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b30a5da4849c7_30155385 (Smarty_Internal_Template $_smarty_tpl) {
?><h2>404 Page not Found</h2>
<?php }
}
