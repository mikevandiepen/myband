<?php
/* Smarty version 3.1.32, created on 2018-06-05 11:56:24
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\contact.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b165e488ae115_78185989',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '64ee96d946953f05f403b428e565bc5e228f0965' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\contact.tpl',
      1 => 1528192140,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b165e488ae115_78185989 (Smarty_Internal_Template $_smarty_tpl) {
}
}
