<?php
/* Smarty version 3.1.32, created on 2018-07-11 10:23:24
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\news.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b45be7cb06b91_15445154',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e48004470ce7d45b6527965dc784b65181bae015' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\news.tpl',
      1 => 1531297403,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b45be7cb06b91_15445154 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="default">

<div class="row v-offsetTwo" style="display: flex;">
    <?php if ($_smarty_tpl->tpl_vars['current_page']->value > 1) {?>
        <a href="index.php?page=news&pageno=<?php echo $_smarty_tpl->tpl_vars['current_page']->value-1;?>
">PREVIOUS</a>
    <?php }?>

    <h6><?php echo $_smarty_tpl->tpl_vars['current_page']->value;?>
</h6>

    <?php if ($_smarty_tpl->tpl_vars['current_page']->value < $_smarty_tpl->tpl_vars['number_of_pages']->value) {?>
        <a href="index.php?page=news&pageno=<?php echo $_smarty_tpl->tpl_vars['current_page']->value+1;?>
">NEXT</a>
    <?php }?>
</div>

<h1>Number of pages: <?php echo $_smarty_tpl->tpl_vars['number_of_pages']->value;?>
</h1>

<p>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['articles']->value, 'article');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['article']->value) {
?>
        <br>
        <hr>
        <h2><?php echo $_smarty_tpl->tpl_vars['article']->value[0];?>
</h2>
        <p><?php echo $_smarty_tpl->tpl_vars['article']->value[1];?>
</p>
    <?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</p>
</section>
<?php }
}
