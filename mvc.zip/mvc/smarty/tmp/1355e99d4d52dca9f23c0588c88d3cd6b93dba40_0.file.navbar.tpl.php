<?php
/* Smarty version 3.1.32, created on 2018-07-25 15:40:34
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\navbar.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b587dd2927c47_70237168',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1355e99d4d52dca9f23c0588c88d3cd6b93dba40' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\navbar.tpl',
      1 => 1532526032,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b587dd2927c47_70237168 (Smarty_Internal_Template $_smarty_tpl) {
?>
<section>
    <nav>
        <ul>
            <li><a href="index.php?page=home">Home</a></li>
            <li><a id="red" href="index.php?page=news">News</a></li>
            <li>
                <form method="GET" action="index.php">
                    <input type="hidden" name="page" value="news">
                    <input type="search" name="searchterm">
                    <input type="submit" name="submit_search" value="search">
                </form>
            </li>
        </ul>
    </nav>
</section>
<?php }
}
