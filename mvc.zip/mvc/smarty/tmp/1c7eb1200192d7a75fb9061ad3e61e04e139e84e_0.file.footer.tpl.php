<?php
/* Smarty version 3.1.32, created on 2018-06-04 09:20:48
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b14e8506abe08_90765579',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c7eb1200192d7a75fb9061ad3e61e04e139e84e' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\footer.tpl',
      1 => 1527839641,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b14e8506abe08_90765579 (Smarty_Internal_Template $_smarty_tpl) {
?>
</body>
</html><?php }
}
