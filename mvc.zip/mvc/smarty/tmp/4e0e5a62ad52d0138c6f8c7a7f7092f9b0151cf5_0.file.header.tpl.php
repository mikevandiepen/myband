<?php
/* Smarty version 3.1.32, created on 2018-07-25 15:37:00
  from 'C:\Users\Mike van Diepen\Desktop\mvc\views\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.32',
  'unifunc' => 'content_5b587cfc3dba39_00771280',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4e0e5a62ad52d0138c6f8c7a7f7092f9b0151cf5' => 
    array (
      0 => 'C:\\Users\\Mike van Diepen\\Desktop\\mvc\\views\\header.tpl',
      1 => 1532525434,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5b587cfc3dba39_00771280 (Smarty_Internal_Template $_smarty_tpl) {
?><!doctype html>
<html lang="en">
<head>

    <!-- Meta Data -->
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- Font Awesome-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/solid.css" integrity="sha384-HTDlLIcgXajNzMJv5hiW5s2fwegQng6Hi+fN6t5VAcwO/9qbg2YEANIyKBlqLsiT" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/regular.css" integrity="sha384-R7FIq3bpFaYzR4ogOiz75MKHyuVK0iHja8gmH1DHlZSq4tT/78gKAa7nl4PJD7GP" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/brands.css" integrity="sha384-KtmfosZaF4BaDBojD9RXBSrq5pNEO79xGiggBxf8tsX+w2dBRpVW5o0BPto2Rb2F" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.10/css/fontawesome.css" integrity="sha384-8WwquHbb2jqa7gKWSoAwbJBV2Q+/rQRss9UXL5wlvXOZfSodONmVnifo/+5xJIWX" crossorigin="anonymous">

    <!-- Style Sheets-->
    <link type="text/css" href="public/assets/CSS/style.css" rel="stylesheet">
    <link type="text/css" href="public/assets/CSS/responsive.css" rel="stylesheet">
    <link type="text/css" href="public/assets/CSS/default.css" rel="stylesheet">

    <!-- Page title -->
    <title>Post Malone</title>

    <!-- JS Links -->
    <?php echo '<script'; ?>
 src="/mvc/assets/JS/script.js"><?php echo '</script'; ?>
>
</head>
<body>
<?php }
}
